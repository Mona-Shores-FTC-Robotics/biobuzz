# Inside the robot: shoot while extracting (issue #166)

The shoot-while-extracting routes on "rigid V, turret transfer", seed 3. Each runs with its partner as in the
baselines ("spring hood", 40 in/s) and the transfer's 0.5 s feed.

The robot is the mentor's new CAD with transfer v2 (CAD commit ea86820). A piece:
1. comes in under the roller, which spins while the intake runs and floats up over a NECTAR;
2. runs up the rising wheel lane;
3. seats in the feeder cup on the turret's axis;
4. is popped straight up the turret's axis by the two feeder wheels, through the launcher's flywheels (which spin while it's spun up) and the turret's bore.

The launcher is fixed. Only the turret ring turns to aim; it will carry the hood. The extractor comes down on the way
to a FLOWER and is fully down before the robot drives in.

| Log | Route | Seed 3 |
|---|---|---|
| `qual-right-v-flower-first-l2600-seed3` | Your plan: straight to the far FLOWER, seated through TIP 1, all 8 fired from the seat, then TIP 2's spill | **76**, TIPs at 4.5, 7.8, 21.1 s |
| `qual-right-v-stream-x200-leave1800-seed3` | The partner shoots. We fire the preloads, then stream at the far FLOWER and leave 1.8 s after | **76**, TIPs at 4.5, 10.4, 23.2 s |
| `qual-stages-angled-v-stream-leave-seed3` | The angled partner, streaming at the far FLOWER | 51, TIPs at 3.9, 19.1 s |
| `qual-stages-wall-v-stream-x700-leave-seed3` | The wall partner. Both robots PARK; the far FLOWER is only its fallback | 56, TIPs at 3.9, 20.9 s |

**60 runs, spread on** (re-run here, 7 Oct 15:45 UTC):

| Route | Points | TIP 3 | PARK (both robots) | Problem runs |
|---|---|---|---|---|
| Flower-first l2600 | **67.6** | 37/60 | 119/120 | 0 |
| Right-side stream leave1800 | **70.9** | 47/60 | 119/120 | 0 |
| Angled stream-leave | 51.4 | 5/60 | 73/120 | 0 |
| Wall stream-x700-leave (refitted to the wall PARK) | 52.3 | 0/60 (TIP 2 in 54) | 120/120 | 0 |

The wall route is refitted to the wall pairing where both robots PARK. The body designs chat's 56.0 was from 10 runs.

## Install (once)

1. Install AdvantageScope **v27.0.0-alpha-6 or newer**, and set it up once as in the repo's README (*How to watch*).
2. Copy the `Robot_BIOBUZZ` folder into AdvantageScope's `userAssets` folder (Help → Show Assets Folder), replacing
   the old one. Restart AdvantageScope.
3. **File → Import Layout…** → `advantagescope-layout-internals.json`.

## Watch

**File → Open Log(s)…** → a log in `logs/`, then press **Space**. The tabs:
- **Field:** the whole field.
- **Inside the robot:** orbits the robot; drag to look into the lane, the cup and the feeders.
- **Limelight:** the fixed camera's view.
- **Internals:** graphs of the turret angle and its lag, the extractor angle, the roller's float, the pieces being fed, and the pieces held.

The rollers, feeders and flywheels spin at a slow display rate (2 turns a second), only to show they're running. Real
speeds would alias at the log's 50 frames a second. Times above are match time; AdvantageScope's timeline adds the
log's 1 s pre-roll.
