# Inside the robot: shoot while extracting (issue #166)

The shoot-while-extracting routes on "rigid V, turret transfer", seed 3. Each runs with its partner as in the
baselines ("spring hood", 40 in/s), the transfer's 0.5 s feed, and the simulator's new wall check (a corner or V tip
more than 0.5 in outside the field is a problem).

The robot is the mentor's CAD with transfer v3, with the launcher and turret 0.8 in forward (CAD commit 2f78001, the transfer simplified for build). A
piece:
1. comes in under the roller, which spins while the intake runs and floats up over a NECTAR;
2. runs up the ramp and along the flat lane;
3. waits between the feeder and a sprung pad on the turret's axis (the pad swings out for a NECTAR), with the rest queued
   nose to tail behind it;
4. is driven straight up by the feeder into the launcher's flywheels (which spin while it's spun up), and on up
   through the turret to the shot's start.

The launcher is fixed. Only the turret ring turns to aim; it will carry the hood. The extractor comes down on the way
to a FLOWER and is fully down before the robot drives in.

| Log | Route | Seed 3 |
|---|---|---|
| `qual-right-v-flower-first-hold-seed3` | **The mentor's flower first.** Fire the 4 preloads from the seat one at a time, hold until the FLOWER's 4 are in, back out to N_FIRE and fire them there, stopped and lined up | **76**, TIPs at 4.5, 9.2, 21.6 s |
| `qual-right-v-flower-first-l2600-seed3` | Flower first, streaming all 8 from the seat. Kept for comparison; the hold version replaces it | 76, TIPs at 4.5, 7.8, 20.6 s |
| `qual-right-v-stream-x200-leave1800-seed3` | The partner shoots. We fire the preloads, then stream at the far FLOWER and leave 1.8 s after | 56, TIPs at 4.5, 10.4 s (3 of TIP 2's spill caught) |
| `qual-stages-angled-v-seed3` | The angled partner: the plain baseline route. The stream version is retired, because it cost PARK | 51, TIPs at 3.8, 21.0 s |
| `qual-stages-wall-v-stream-x700-leave-seed3` | The wall partner. Both robots PARK; the far FLOWER is only its fallback | 56, TIPs at 3.8, 20.8 s |

**60 runs, spread on** (re-run here, 7 Oct 17:45 UTC):

| Route | Points | TIP 3 | PARK (both robots) | Problem runs |
|---|---|---|---|---|
| **Flower-first hold** | **70.6** | 47/60 | 119/120 | 0 |
| Flower-first l2600 | 65.3 | 32/60 | 119/120 | 0 |
| Right-side stream leave1800 | 69.3 | 43/60 | 119/120 | 0 |
| Angled (plain baseline) | 53.8 | 6/60 | 113/120 | 2: our robot's corner through a wall at 26.8 s, after AUTO's last TIP |
| Wall stream-x700-leave | 52.7 | 0/60 (TIP 2 in 54) | 120/120 | 0 |

The body designs chat's 70.0 for the hold and stream routes was from 10 runs.

## Install (once)

1. Install AdvantageScope **v27.0.0-alpha-6 or newer**, and set it up once as in the repo's README (*How to watch*).
2. Copy the `Robot_BIOBUZZ` folder into AdvantageScope's `userAssets` folder (Help → Show Assets Folder), replacing
   the old one. Restart AdvantageScope.
3. **File → Import Layout…** → `advantagescope-layout-internals.json`.

## Watch

**File → Open Log(s)…** → a log in `logs/`, then press **Space**. The tabs:
- **Field:** the whole field.
- **Inside the robot:** orbits the robot; drag to look into the lane, the feeder and the pad.
- **Limelight:** the fixed camera's view.
- **Internals:** graphs of the turret angle and its lag, the extractor angle, the roller's float, the pieces being fed, and the pieces held.

The rollers, feeders and flywheels spin at a slow display rate (2 turns a second), only to show they're running. Real
speeds would alias at the log's 50 frames a second. Times above are match time; AdvantageScope's timeline adds the
log's 1 s pre-roll.
