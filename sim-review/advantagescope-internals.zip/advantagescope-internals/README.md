# Inside the robot: the four routes for review (issue #166)

**60 runs each**, on "rigid V, turret transfer", with the partner as in the baselines ("spring hood", 40 in/s), the
transfer's 0.5 s feed, and the simulator's wall check. Re-run here on 7 Oct, 19:45 UTC.

| Route | Points | TIP 3 | PARK (both robots) | Problem runs | Log (seed 3) |
|---|---|---|---|---|---|
| **Seat fire, west** (`qual-right-v-seatfire-west`): the best right-side Auto | **72.3** | 52/60 | 120/120 | 0 | 76 points, TIPs at 4.5, 10.9, 24.8 s |
| **Flower first, hold** (`qual-right-v-flower-first-hold`) | **70.6** | 47/60 | 119/120 | 1 | 76 points, TIPs at 4.5, 10.0, 23.5 s |
| Angled partner (`qual-stages-angled-v`, plain) | 52.6 | 0/60 (TIP 2 in 54) | 119/120 | **9: into the HIVE frame at about 26 s** | 56 points, TIPs at 4.0, 21.5 s |
| Wall partner (`qual-stages-wall-v-stream-x700-leave`) | 53.3 | 0/60 (TIP 2 in 56) | 120/120 | 0 | 56 points, TIPs at 4.0, 17.8 s |

Seed 3 is a typical run for each route. In seeds 1–10, the right-side routes make 3 TIPs in 7 or 8, and the Stages
routes 2 TIPs in 9 or 10. So each log here is the usual case, not a lucky one.

**Problem runs.** Flower first's one was a run that never fired: it hit a FLOWER at 26.3 s and the HIVE frame at
27.4 s. The angled route's nine drive into the HIVE frame late in AUTO. Both routes belong to the simulator and body
designs chats.

## What you see

The robot is the mentor's CAD with the simplified transfer (CAD commit 2f78001). A piece:
1. comes in under the roller, which spins while the intake runs and floats up over a NECTAR;
2. runs up the ramp and along the flat lane;
3. waits between the feeder and a sprung pad on the turret's axis, with the rest queued nose to tail behind it. The
   pad swings out for a NECTAR;
4. is driven straight up by the feeder into the launcher's flywheels (which spin while it's spun up), and on up
   through the turret to where the shot starts.

The launcher is fixed. Only the turret ring turns to aim; it will carry the hood. The extractor comes down on the way
to a FLOWER and is fully down before the robot drives in.

## Install (once)

1. Install AdvantageScope **v27.0.0-alpha-6 or newer**, and set it up once as in the repo's README (*How to watch*).
2. Copy the `Robot_BIOBUZZ` folder into AdvantageScope's `userAssets` folder (Help → Show Assets Folder), replacing
   the old one. Restart AdvantageScope.
3. **File → Import Layout…** → `advantagescope-layout-internals.json`.

## Watch

**File → Open Log(s)…** → a log in `logs/`, then press **Space**. The tabs:
- **Field:** the whole field.
- **Inside the robot:** orbits the robot; drag to look into the lane, the feeder and the pad.
- **Limelight:** the fixed camera's view.
- **Internals:** graphs of the turret angle and its lag, the extractor angle, the roller's float, the pieces being fed, and the pieces held.

The rollers, feeder and flywheels spin at a slow display rate (2 turns a second), only to show they're running. Real
speeds would alias at the log's 50 frames a second. Times above are match time; AdvantageScope's timeline adds the
log's 1 s pre-roll.
