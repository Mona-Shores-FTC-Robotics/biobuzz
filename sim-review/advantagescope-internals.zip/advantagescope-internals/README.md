# Inside the robot: sample logs (issue #166)

Three simulated qualifier Autos on the "rigid V, transfer" design (seed 3), with the robot's insides drawn:
- each held piece on the transfer's path: under the roller, up the ramp, queued in the lane, round the J and up the turret axis;
- the extractor swinging, the roller floating over a NECTAR, the turret aiming and the J arm lifting.

The full write-up is `doc/advantagescope-internals.md` on `spike/166-advantagescope-internals`.

| Log | Auto | Points | TIPs at (s) |
|---|---|---|---|
| `qual-right-v-transfer-seed3` | qual-right-v (the partner shoots) | 76 | 4.0, 11.3, 23.6 |
| `qual-stages-angled-v-transfer-seed3` | qual-stages-angled-v | 51 | 4.1, 20.7 |
| `qual-stages-wall-v-transfer-seed3` | qual-stages-wall-v | 66 | 4.1, 15.9, 28.2 |

## Install (once)

1. Install AdvantageScope **v27.0.0-alpha-6 or newer**, and set it up once as in the repo's README (*How to watch*).
2. Copy the `Robot_BIOBUZZ` folder into AdvantageScope's `userAssets` folder (Help → Show Assets Folder), replacing
   the old one. Restart AdvantageScope.
3. **File → Import Layout…** → `advantagescope-layout-internals.json`.

## Watch

**File → Open Log(s)…** → a log in `logs/`, then press **Space**. The tabs:
- **Field:** the whole field.
- **Inside the robot:** orbits the robot; drag to look into the lane and the J.
- **Limelight:** the fixed camera's view.
- **Internals:** graphs of the turret angle and its lag, the extractor angle, the roller's float, the J arm, and the pieces held.

The turret and the J arm are model components 2 and 3. Until the CAD model exports them, they show only in the
graphs.
