# Inside the robot: shoot while extracting (issue #166)

The routes the body designs chat asked for, on "rigid V, turret transfer", seed 3. Each has its partner as in the
baselines ("spring hood", 40 in/s). The extractor seats with the FLOWER's centre **4.59 in** ahead of the face (CAD
c04f0cb), so it reaches under the FLOWER. Drawn with the robot's insides:
- each held piece on the transfer's path: under the roller, up the ramp, queued in the lane, round the J and up the
  turret axis;
- the extractor swinging, the roller floating over a NECTAR, the turret aiming and the J arm lifting.

## Two sets of logs: the transfer's feed time

The simulator branches disagree on one number, so there are two sets.
- **`feed-0.5s/`:** the merged simulator. `claude/simulator` makes a piece wait a placeholder **0.5 s** after it is
  taken in before it can be fired (`RobotDesign.transferFeedS`).
- **`feed-0s/`:** the body designs branch's assumption. A piece can be fired as soon as it's held. This is the merged
  simulator with that one number at 0 (not committed).

| Route | feed 0 s | feed 0.5 s |
|---|---|---|
| `qual-right-v-flower-first-l2000` (to the far FLOWER first, all 8 fired from the seat) | **76**, TIPs at 4.5, 7.9, 19.9 s | 36, TIP at 4.5 s only |
| `qual-stages-angled-v-stream-leave` | 51, TIPs at 3.9, 18.8 s | 51, TIPs at 3.9, 19.3 s |
| `qual-stages-wall-v-stream-x700-leave` | 51, TIPs at 3.9, 19.8 s | 51, TIPs at 3.9, 20.1 s |

**Why flower-first falls to 36 at 0.5 s:** the route streams from the seat for 2 s (4.6–6.6 s). With the 0.5 s feed,
the FLOWER's POLLEN are ready only at 6.0, 6.5 and 7.0 s, so 3 preloads go and TIP 2 never comes. With no TIP 2,
the only raised CELL is 60.7 in from S_FIRE, out of range, so the later `LaunchAll`s fire nothing.

The transfer's own figure for intake to ready to fire is 0.35 s (`doc/transfer.md` on `spike/164-transfer`).

## Install (once)

1. Install AdvantageScope **v27.0.0-alpha-6 or newer**, and set it up once as in the repo's README (*How to watch*).
2. Copy the `Robot_BIOBUZZ` folder into AdvantageScope's `userAssets` folder (Help → Show Assets Folder), replacing
   the old one. Restart AdvantageScope.
3. **File → Import Layout…** → `advantagescope-layout-internals.json`.

## Watch

**File → Open Log(s)…** → a log in `logs/`, then press **Space**. The tabs:
- **Field:** the whole field.
- **Inside the robot:** orbits the robot; drag to look into the lane and the J.
- **Limelight:** the fixed camera's view.
- **Internals:** graphs of the turret angle and its lag, the extractor angle, the roller's float, the J arm, and the pieces held.

The model has all four moving parts (CAD commit c04f0cb: the extractor's arms outside the FLOWER, stowed at 146°).
The turret is drawn as its bearing only, until the launcher has an outline.
