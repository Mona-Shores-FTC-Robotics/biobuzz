# Inside the robot: shoot while extracting (issue #166)

The shoot-while-extracting routes on "rigid V, turret transfer", seed 3. Each runs with its partner as in the
baselines ("spring hood", 40 in/s) and the transfer's 0.5 s feed. The extractor seats with the FLOWER's centre
**4.59 in** ahead of the face (CAD c04f0cb), so you see it reach under the FLOWER.

Drawn with the robot's insides:
- each held piece on the transfer's path: under the roller, up the ramp, queued in the lane, round the J and up the
  turret axis;
- the extractor swinging, the roller floating over a NECTAR, the turret aiming and the J arm lifting.

| Log | Route | Seed 3 |
|---|---|---|
| `qual-right-v-flower-first-l2600-seed3` | Your plan: straight to the far FLOWER, seated through TIP 1, all 8 fired from the seat (2.6 s there), then TIP 2's spill | **76**, TIPs at 4.5, 8.4, 20.5 s |
| `qual-right-v-stream-x200-leave1800-seed3` | The partner shoots; we fire the preloads, then stream at the far FLOWER and leave 1.8 s after (sized for the 0.5 s feed) | **76**, TIPs at 4.5, 10.5, 23.2 s |
| `qual-stages-angled-v-stream-leave-seed3` | The angled partner, streaming at the far FLOWER | 51, TIPs at 3.9, 19.3 s |
| `qual-stages-wall-v-stream-x700-leave-seed3` | The wall partner, streaming at the far FLOWER | 51, TIPs at 3.9, 20.1 s |

**Flower-first over 60 runs** (the body designs chat; I re-ran the 71.3 here and got the same):

| Spread | Points | TIP 3 | PARK | G409 runs |
|---|---|---|---|---|
| on (as the logs) | 71.3 | 48/60 | 59/60 | 20 |
| zero | 73.3 | 52/60 | 60/60 | 35 |

**Right-side stream over 60 runs** (spread on): 71.6 points, TIP 3 in 49/60, PARK 59/60; with a 1.3 s leave it keeps the 4th POLLEN aboard and scores 37.9.

No problem runs. On flower-first the robot needs about 2.6 s at the seat: at 1.8 or 2.2 s it leaves before the FLOWER's pieces reach
the turret (0.5 s feed), TIP 2 never comes, and it scores 36.

## Install (once)

1. Install AdvantageScope **v27.0.0-alpha-6 or newer**, and set it up once as in the repo's README (*How to watch*).
2. Copy the `Robot_BIOBUZZ` folder into AdvantageScope's `userAssets` folder (Help → Show Assets Folder), replacing
   the old one. Restart AdvantageScope.
3. **File → Import Layout…** → `advantagescope-layout-internals.json`.

## Watch

**File → Open Log(s)…** → a log in `logs/`, then press **Space**. The tabs:
- **Field:** the whole field.
- **Inside the robot:** orbits the robot; drag to look into the lane and the J.
- **Limelight:** the fixed camera's view.
- **Internals:** graphs of the turret angle and its lag, the extractor angle, the roller's float, the J arm, and the pieces held.

The model has all four moving parts (CAD a096022). The extractor's arms sit outside the FLOWER, stowed at 146°. The
turret carries the designer's Launcher Concept: goBILDA's turret with two 96 mm flywheel pairs under it, turning
with it. The transfer's J and chute aren't yet redrawn to feed those flywheels, so a piece climbing the J is drawn
passing through them. The transfer chat is redrawing it.
