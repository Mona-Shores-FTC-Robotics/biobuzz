# Inside the robot: the routes for review (issue #166)

**60 runs each**, on "rigid V": the decided robot, with the turret, the transfer, the extractor and a shot every
**0.2 s**. Each runs with the partner as in the baselines ("spring hood", 40 in/s), the transfer's 0.5 s feed, and
the simulator's wall check. Re-run here on 7 Oct, 20:50 UTC. Each route's partner route is given after the @.

| Route | Points | TIP 3 | PARK (both robots) | Problem runs | Log (seed 3) |
|---|---|---|---|---|---|
| **Flower first, TIP 3** (`qual-right-v-flower-first-tip3` @ `partner-preloads-right-high`) | **74.0** | 56/60 | 120/120 | 0 | 76 points, TIPs at 3.8, 8.9, 21.7 s; then fills up from TIP 3's spill and PARKs about 8 in deep at 28.1 s, 1 piece held |
| **Flower first, hold** (`qual-right-v-flower-first-hold` @ `partner-preloads-right`), for comparison | **74.0** | 56/60 | 120/120 | 0 | 76 points, TIPs at 3.8, 8.9, 21.7 s |
| **Seat fire, west** (`qual-right-v-seatfire-west`) | **72.7** | 52/60 | 120/120 | 0 | 76 points, TIPs at 3.8, 10.0, 23.7 s |
| Angled partner (`qual-stages-angled-v`, plain) | 61.3 | 24/60 | 120/120 | **4: into the HIVE frame at about 26 s** | 76 points, TIPs at 3.9, 14.3, 26.1 s |
| Wall partner (`qual-stages-wall-v-stream-x700-leave`) | 53.3 | 0/60 (TIP 2 in 56) | 120/120 | 0 | 56 points, TIPs at 3.9, 16.3 s |

**Flower first, TIP 3** is flower first, hold with the mentor's first two comments: after the GARDEN's shots it waits for
TIP 3, turns west at (50, 24), collects what the webcam sees of the spill, then parks up the west side at (10.5, 95).
Its partner parks at the zone's far end, (10.5, 116). It scores the same as hold, and carries 1.7 pieces into TELEOP on
average instead of 0.3.

Seed 3 is a typical run on three of the routes: in seeds 1–10, the right-side routes make 3 TIPs in 7 or 9, and the
wall route 2 TIPs in all 10. On the angled route 3 TIPs come in 24 of 60, so its seed-3 log is one of the better
runs; 2 TIPs is as common.

**Problem runs.** The angled route's four drive into the HIVE frame late in AUTO. It is the simulator chat's route.

## What you see

The robot is the mentor's CAD with the simplified transfer (CAD commit 2f78001). A piece:
1. comes in under the roller, which spins while the intake runs and floats up over a NECTAR;
2. runs up the ramp and along the flat lane;
3. waits between the feeder and a sprung pad on the turret's axis, with the rest queued nose to tail behind it. The
   pad swings out for a NECTAR;
4. is driven straight up by the feeder into the launcher's flywheels (which spin while it's spun up), and on up
   through the turret to where the shot starts.

The launcher is fixed. Only the turret ring turns to aim; it will carry the hood. The extractor comes down on the way
to a FLOWER and is fully down before the robot drives in.

## Install (once)

1. Install AdvantageScope **v27.0.0-alpha-6 or newer**, and set it up once as in the repo's README (*How to watch*).
2. Copy the `Robot_BIOBUZZ` folder into AdvantageScope's `userAssets` folder (Help → Show Assets Folder), replacing
   the old one. Restart AdvantageScope.
3. **File → Import Layout…** → `advantagescope-layout-internals.json`.

## Watch

**File → Open Log(s)…** → a log in `logs/`, then press **Space**. The tabs:
- **Field:** the whole field.
- **Inside the robot:** orbits the robot; drag to look into the lane, the feeder and the pad.
- **Limelight:** the fixed camera's view.
- **Internals:** graphs of the turret angle and its lag, the extractor angle, the roller's float, the pieces being fed, and the pieces held.

The rollers, feeder and flywheels spin at a slow display rate (2 turns a second), only to show they're running. Real
speeds would alias at the log's 50 frames a second. Times above are match time; AdvantageScope's timeline adds the
log's 1 s pre-roll.
