Robot shapes and the spill, for AdvantageScope (biobuzz branch claude/biobuzz-robot-body-designs-hi386c).

1. Copy the folder Robot_BIOBUZZShapes into AdvantageScope's userAssets folder, %APPDATA%\AdvantageScope\userAssets
   (paste that into Explorer's address bar), replacing any older copy, next to Robot_BIOBUZZ and
   Field3d_BIOBUZZHiveSim from the usual setup (tools/advantagescope/setup-hive-assets.ps1 copies this folder too).
   Restart AdvantageScope.
2. File > Import Layout: advantagescope-layout-shapes.json.
3. Open body-all-shapes.wpilog. Every shape parks with its chassis's front face on the 8 POLLEN spill's 100% line
   (35 in from the wall), its walls or flaps reaching into where pieces land, and plays one after another, 4.5 s
   each (1 s before our CELL tips to 3 s after). The simulator ran each shape: pieces bounce off its walls and
   flaps. The robot switches shape by itself; the Console names each one ("SHAPE 3 of 16: ...") and ends it with
   how many pieces it kept and any G409 touch (on the chassis, or on a guide only); /BodyShape/Name shows it too.
     A typical TIP:                       The same shapes on a TIP where a piece lands on the long U's walls:
      0.0 s plain 18                       36.0 s plain 18
      4.5 s long U                         40.5 s long U
      9.0 s (a) 16 + flaps 3 out, 2 fwd    45.0 s (a)
     13.5 s (b) 16 + flaps 4 out, 2 fwd    49.5 s (b) 16
     18.0 s (b) 15 + flaps 4.5 out, 3 fwd  54.0 s (b) 15
     22.5 s (c) 18 x 15 + flaps 3, 3       58.5 s (c)
     27.0 s 16 + long flaps 1 out, 8 fwd   63.0 s long flaps
     31.5 s 18 + low ramps 6 fwd           67.5 s low ramps
   logs/ has the typical TIP as one file per shape, if you want to loop one.
