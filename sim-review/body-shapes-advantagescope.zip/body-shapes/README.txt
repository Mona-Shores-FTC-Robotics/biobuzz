Robot shapes and the spill, for AdvantageScope (biobuzz branch claude/biobuzz-robot-body-designs-hi386c).

1. Copy the folder Robot_BIOBUZZShapes into AdvantageScope's userAssets folder, %APPDATA%\AdvantageScope\userAssets
   (paste that into Explorer's address bar), next to Robot_BIOBUZZ and Field3d_BIOBUZZHiveSim from the usual
   setup (tools/advantagescope/setup-hive-assets.ps1, which now copies this folder too). Restart AdvantageScope.
2. File > Import Layout: advantagescope-layout-shapes.json.
3. Open a log from logs/. Each is the same TIP (8 POLLEN) with the robot parked at that shape's closest spot
   with no G409 touch in 200 TIPs. The 3D tab draws the shape (the see-through box is what the simulator
   bounces pieces off, 14 in tall). The Console lists "sim: G409" touches and, at the end, how many pieces
   were kept.
   *-too-close.wpilog: two flap shapes 3 in nearer, on a TIP where a piece lands on a flap.
