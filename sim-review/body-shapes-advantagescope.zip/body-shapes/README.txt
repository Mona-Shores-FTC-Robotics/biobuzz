Robot shapes and the spill, for AdvantageScope (biobuzz branch claude/biobuzz-robot-body-designs-hi386c).

1. Copy the folder Robot_BIOBUZZShapes into AdvantageScope's userAssets folder, %APPDATA%\AdvantageScope\userAssets
   (paste that into Explorer's address bar), next to Robot_BIOBUZZ and Field3d_BIOBUZZHiveSim from the usual
   setup (tools/advantagescope/setup-hive-assets.ps1, which now copies this folder too). Restart AdvantageScope.
2. File > Import Layout: advantagescope-layout-shapes.json.
3. Open body-all-shapes.wpilog. It plays every shape one after another, about 4.5 s each, on the same TIP
   (8 POLLEN): 1 s before our CELL tips to 3 s after. The robot switches shape by itself. The Console names each
   shape as it starts ("SHAPE 4 of 11: ...") and ends it with how many pieces it kept and any G409 touch; the key
   /BodyShape/Name shows the shape on screen. Each shape is parked at its closest spot with no G409 touch in
   200 TIPs, and the simulator really ran it: pieces bounce off that shape's flaps and walls.
     0.0 s plain 18           4.5 s long U             9.0 s plain 16
    13.5 s (a) 16 + 3/2      18.0 s (b) 16 + 4/2      22.5 s (b) 15 + 4.5/3
    27.0 s (c) 18x15 + 3/3   31.5 s 16 + 1/8 flared   36.0 s 18 + low ramps
    40.5 s (a) too close     45.0 s flared too close   (3 in nearer, a TIP where a piece lands on a flap)
   logs/ has the same runs as one file each, if you want to loop one.
