The deep dive (biobuzz branch claude/biobuzz-robot-body-designs-hi386c, 6 Oct 2026): the qualifier Autos on option 3
with each body shape, simulated in full. The report says what the numbers mean; this has the matches to watch.

1. Copy the folder Robot_BIOBUZZMatchShapes into AdvantageScope's userAssets folder,
   %APPDATA%\AdvantageScope\userAssets (paste that into Explorer's address bar), replacing any older copy, next to
   the HIVE assets from the usual setup. Restart AdvantageScope.
2. File > Import Layout: advantagescope-layout-match-shapes.json (the usual match layout, our robot drawn as its shape).
3. Open a log from logs/. Each is <partner>-<body>-typical (the median of 20 runs on normal tiles) or -best.
   Partners: right (fires its 4 from the right start: TIP 1), left (fires its 4 from the left start once we've
   tipped), nothing (only drives and parks), stages-angled and stages-wall (can't shoot; its 4 POLLEN start on the
   tiles beside it).
   Bodies, all option 3 (14.5 in square, 14 in intake) unless named: plain, rigid V, funnel flaps, dual hook (an arm
   each side, the one toward the centre line comes down), 12.5 in dual hook (option 3 shortened to 12.5 in).
   The Console lists every command and TIP; "hook down" / "hook up" when the hook swings; any "sim: G409" touch says
   where the piece was and which part of the robot it reached.
