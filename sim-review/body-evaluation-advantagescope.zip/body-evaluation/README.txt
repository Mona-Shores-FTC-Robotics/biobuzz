Ramp Hook vs Rigid V (biobuzz branch claude/biobuzz-robot-body-designs-hi386c, 6 Oct 2026, current physics).
The report, sim-review/body-evaluation.html, says what the numbers mean; this has the matches to watch.

1. Copy the folder Robot_BIOBUZZ into AdvantageScope's userAssets folder,
   %APPDATA%\AdvantageScope\userAssets (paste that into Explorer's address bar), replacing any older copy.
   Restart AdvantageScope. (It draws every guide: the robot in each log is drawn as its own guide.)
2. File > Import Layout: advantagescope-layout.json.
3. Open a log from logs/: <Auto>-<guide>-typical (the median of 60 runs) or -best (ShootsRight only).
   Autos: shootsright (the partner fires its 4 from the right start), shootsright-parkfirst (the Rigid V routes
   that PARK when TIP 3 is late), stagesangled and stageswall (the partner can't shoot; its 4 POLLEN start on
   the tiles beside it).
   Guides: flat-intake (none), rigid-v-18-45 (the Rigid V), rigid-v-18-30 (longer), rigid-v-20-45 (wider),
   ramp-hook (drawn as the 8 in hook).
   The Console lists every command and TIP; "hook down" / "hook up" when the hook swings; any "sim: G409"
   touch says where the piece was and which part of the robot it reached.
