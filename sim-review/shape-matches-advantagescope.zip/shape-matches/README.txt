The spill shapes in the whole Qualifier Auto (qual-right-v3 with its partner), simulated 5 Oct 2026
(biobuzz branch claude/biobuzz-robot-body-designs-hi386c; numbers in its README, "In the Qualifier Auto").

1. Copy the folder Robot_BIOBUZZMatchShapes into AdvantageScope's userAssets folder,
   %APPDATA%\AdvantageScope\userAssets (paste that into Explorer's address bar), next to the HIVE assets from
   the usual setup (tools/advantagescope/setup-hive-assets.ps1 copies this folder too). Restart AdvantageScope.
2. File > Import Layout: advantagescope-layout-match-shapes.json (the usual match layout, our robot drawn as
   its shape).
3. Open a log from logs/: shape-match-<design>-best (the highest-scoring of 20 runs on normal tiles) or
   -typical (the median one). Designs on option 3, the robot the build team is heading toward (14.5 in
   square, 14 in intake), Auto qual-right-o3: o3-plain, o3-rigid-v, o3-large-hook, o3-small-hook.
   The same shapes on the older 18 in spring-hood robot, Auto qual-right-v3: plain, rigid-v, large-hook,
   small-hook.
   -seed19 (option 3) and -seed7 (18 in robot): the same match for every design, so they can be compared
   side by side.
   Watch TIP 2 (about 13.9 s): a hook robot rides with its hook (arm and crossbeam) stowed, swung up inside the
   front of its frame. As TIP 2 starts it swings the hook down (0.3 s, "hook down" in the Console) while it slides
   about 4 in toward the centre line, holds the spill, and swings the hook back up as it drives off ("hook up").
   Its arm is on the robot's left, the side facing the centre line here.
   The Console lists every command, TIP and any "sim: G409" touch.
