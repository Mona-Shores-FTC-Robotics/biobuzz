The spill shapes in the whole Qualifier Auto (qual-right-v3 with its partner), simulated 5 Oct 2026
(biobuzz branch claude/biobuzz-robot-body-designs-hi386c; numbers in its README, "In the Qualifier Auto").

1. Copy the folder Robot_BIOBUZZMatchShapes into AdvantageScope's userAssets folder,
   %APPDATA%\AdvantageScope\userAssets (paste that into Explorer's address bar), next to the HIVE assets from
   the usual setup (tools/advantagescope/setup-hive-assets.ps1 copies this folder too). Restart AdvantageScope.
2. File > Import Layout: advantagescope-layout-match-shapes.json (the usual match layout, our robot drawn as
   its shape).
3. Open a log from logs/: shape-match-<design>-best (the highest-scoring of 20 runs on normal tiles) or
   -typical (the median one). Designs: plain, rigid-v, large-hook, small-hook.
   Watch TIP 2 (about 13.5 s): a hook robot slides about 4 in toward the centre line as the TIP starts, lowers
   its arm and crossbeam once it has stopped (the Console says "hook down ... arm on the left"), and lifts them
   when it drives off into the spill. Facing our far wall, the side toward the centre line is the robot's left.
   The Console lists every command, TIP and any "sim: G409" touch.
