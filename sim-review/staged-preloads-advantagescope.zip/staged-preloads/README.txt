Our preloads staged in the hook while we wait for TIP 1 (qual-right-v3 with its partner), simulated 5 Oct 2026
(biobuzz branch spike/159-staged-preloads-hook, issue #159; numbers in its README, "Staging our preloads in the hook").

1. Copy the folder Robot_BIOBUZZMatchShapes into AdvantageScope's userAssets folder,
   %APPDATA%\AdvantageScope\userAssets (paste that into Explorer's address bar), next to the HIVE assets from the
   usual setup. It is the same model as in shape-matches-advantagescope.zip. Restart AdvantageScope.
2. File > Import Layout: advantagescope-layout-staged.json. It is the match-shapes layout plus a magenta ring round
   each staged preload (/Sim/Staged/Ring0-3) while it lies loose on the tiles. A ring goes away once a robot holds
   the piece again.
3. Open a log from logs/: staged-<case>-best (the highest-scoring of 20 runs on normal tiles) or -typical (the
   median one). Cases:
     v3-large-hook          qual-right-v3-large-hook, no staging: the comparison
     stage-at-n-fire        the idea as first drawn, staged from N_FIRE. Watch 4.6 s: the left CELL swings up
                            at TIP 1 and throws the staged pieces
     stage-back-large-hook  staged from y 120: hook down at 1.0 s, preloads out, hook up at about 2.5 s, the FLOWER,
                            fired at TIP 1, the staged 4 taken back with the webcam and fired for TIP 2
     stage-back-plain       the same route on the plain 18 in robot (no hook)
   The Console lists "hook down: the Auto asked" / "hook up: the Auto asked" (HookDown/HookUp), the TIP-triggered
   "hook down: our CELL started to TIP", each "sim: outtake", and any "sim: G409" touch.
